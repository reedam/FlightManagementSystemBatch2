package com.capg.Exception;

public class FlightManagmentException extends Exception{
	
	public FlightManagmentException(String s)
	{
		super(s);
	}

}
