export class Flight {
    flightNumber:string;
    flightModel:string;
    carrierName:string;
    seatCapacity:number;
}
