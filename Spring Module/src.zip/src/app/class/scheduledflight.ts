import { Flight } from './flight';
import { Schedule } from './schedule';

export class Scheduledflight {
    scheduledFlightId:number;
    flight:Flight;
    availableSeats:number;
    schedule:Schedule;
    
}
