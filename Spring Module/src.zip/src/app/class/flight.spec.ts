import { Flight } from './flight';

describe('Flight', () => {
  it('should create an instance', () => {
    expect(new Flight()).toBeTruthy();
  });
});
