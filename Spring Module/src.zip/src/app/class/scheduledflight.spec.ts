import { Scheduledflight } from './scheduledflight';

describe('Scheduledflight', () => {
  it('should create an instance', () => {
    expect(new Scheduledflight()).toBeTruthy();
  });
});
